// ONLY A COMMENT

$(document).ready(function() {
    // all of your code goes in here
    // it runs after the DOM is built
    var mat = "My new text with a variable  - only works after the DOM has loaded"
	document.getElementById("MyEdit").innerHTML = mat;
});
